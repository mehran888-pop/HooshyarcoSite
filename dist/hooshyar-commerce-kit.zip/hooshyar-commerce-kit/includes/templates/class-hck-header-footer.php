<?php
/**
 * Header & Footer module.
 *
 * Provides multiple professional header/footer presets (default,
 * modern, minimal, creative) with selectable layouts.
 *
 * WordPress loads header.php / footer.php through locate_template()
 * which has no filter, so the plugin uses the battle-tested technique
 * of hooking `get_header` / `get_footer`: it prints the custom header
 * (with full document chrome) and then includes the theme template
 * inside an output buffer so its markup is discarded (require_once
 * guarantees the theme file is not executed twice).
 *
 * Elementor Pro users can instead assign Elementor templates — the
 * plugin renders the selected template inside the document chrome.
 *
 * @package HooshyarCommerceKit
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class HCK_Header_Footer
 */
class HCK_Header_Footer {

	/**
	 * Singleton.
	 *
	 * @var HCK_Header_Footer|null
	 */
	private static $instance = null;

	/**
	 * Whether the custom header was already printed this request.
	 *
	 * @var bool
	 */
	private $header_done = false;

	/**
	 * Whether the custom footer was already printed this request.
	 *
	 * @var bool
	 */
	private $footer_done = false;

	/**
	 * Instance.
	 *
	 * @return HCK_Header_Footer
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'get_header', array( $this, 'replace_header' ), 5 );
		add_action( 'get_footer', array( $this, 'replace_footer' ), 5 );
		add_filter( 'body_class', array( $this, 'body_classes' ) );
		add_filter( 'render_block', array( $this, 'filter_template_part_blocks' ), 10, 2 );
		add_shortcode( 'hck_category_menu', array( __CLASS__, 'shortcode_category_menu' ) );
	}

	/**
	 * Should custom header/footer be used on the current request?
	 *
	 * @return bool
	 */
	public function should_use_custom() {
		if ( is_admin() || wp_doing_ajax() ) {
			return false;
		}

		$scope = HCK_Helpers::get( 'header_footer_scope', 'entire_site' );

		switch ( $scope ) {
			case 'front_only':
				return is_front_page();

			case 'shop_only':
				return ( function_exists( 'is_shop' ) && is_shop() )
					|| is_product_category()
					|| is_product_tag()
					|| is_post_type_archive( 'product' );

			case 'custom_ids':
				$ids = array_filter( array_map( 'absint', explode( ',', (string) HCK_Helpers::get( 'header_footer_ids', '' ) ) ) );
				return is_page() && in_array( get_queried_object_id(), $ids, true );

			case 'entire_site':
			default:
				return true;
		}
	}

	/**
	 * Print the custom header and swallow the theme's header.php output.
	 *
	 * @param string|null $name Header name argument passed to get_header().
	 */
	public function replace_header( $name = null ) {
		if ( $this->header_done || ! $this->should_use_custom() ) {
			return;
		}
		$this->header_done = true;

		$file = HCK_PLUGIN_DIR . 'templates/header/header.php';
		if ( ! is_readable( $file ) ) {
			return;
		}

		// Print our header (full document chrome + header markup).
		require $file;

		// Prevent the theme header's wp_head / wp_body_open from running twice.
		remove_all_actions( 'wp_head' );
		remove_all_actions( 'wp_body_open' );

		// Capture the theme's header.php output and discard it. Because
		// load_template() uses require_once, the later load inside
		// get_header() becomes a no-op.
		$templates = array();
		if ( $name ) {
			$templates[] = 'header-' . $name . '.php';
		}
		$templates[] = 'header.php';

		ob_start();
		locate_template( $templates, true, true );
		ob_end_clean();
	}

	/**
	 * Print the custom footer and swallow the theme's footer.php output.
	 */
	public function replace_footer() {
		if ( $this->footer_done || ! $this->should_use_custom() ) {
			return;
		}
		$this->footer_done = true;

		$file = HCK_PLUGIN_DIR . 'templates/footer/footer.php';
		if ( ! is_readable( $file ) ) {
			return;
		}

		require $file;

		remove_all_actions( 'wp_footer' );

		ob_start();
		locate_template( array( 'footer.php' ), true, true );
		ob_end_clean();
	}

	/**
	 * Block-theme support: replace the header/footer template-part blocks
	 * with the selected HCK templates.
	 *
	 * Classic themes are handled by `get_header` / `get_footer`; block themes
	 * never call those functions, they render `core/template-part` blocks.
	 *
	 * @param string $block_content Rendered block content.
	 * @param array  $block         Block data.
	 * @return string
	 */
	public function filter_template_part_blocks( $block_content, $block ) {
		if ( is_admin() || wp_doing_ajax() || empty( $block['blockName'] ) || 'core/template-part' !== $block['blockName'] ) {
			return $block_content;
		}

		$slug = isset( $block['attrs']['slug'] ) ? (string) $block['attrs']['slug'] : '';
		$area = isset( $block['attrs']['area'] ) ? (string) $block['attrs']['area'] : '';

		$is_header = ( 'header' === $slug || 'header' === $area );
		$is_footer = ( 'footer' === $slug || 'footer' === $area );

		if ( ! $is_header && ! $is_footer ) {
			return $block_content;
		}

		if ( ! $this->should_use_custom() ) {
			return $block_content;
		}

		if ( $is_header ) {
			if ( $this->header_done ) {
				return '';
			}
			$this->header_done = true;

			$header_id = (int) HCK_Helpers::get( 'header_elementor_id', 0 );
			if ( $header_id && HCK_Helpers::is_elementor_active() ) {
				return self::render_elementor_template( $header_id );
			}
			return self::render_header( HCK_Helpers::get( 'header_template', 'modern' ) );
		}

		// Footer.
		if ( $this->footer_done ) {
			return '';
		}
		$this->footer_done = true;

		$footer_id = (int) HCK_Helpers::get( 'footer_elementor_id', 0 );
		if ( $footer_id && HCK_Helpers::is_elementor_active() ) {
			return self::render_elementor_template( $footer_id );
		}
		return self::render_footer( HCK_Helpers::get( 'footer_template', 'modern' ) );
	}

	/**
	 * Body classes.
	 *
	 * @param array $classes Classes.
	 * @return array
	 */
	public function body_classes( $classes ) {
		if ( $this->should_use_custom() ) {
			$classes[] = 'hck-custom-header-footer';
			$classes[] = 'hck-header-' . sanitize_html_class( HCK_Helpers::get( 'header_template', 'modern' ) );
			$classes[] = 'hck-header-layout-' . sanitize_html_class( HCK_Helpers::get( 'header_layout', 'inline' ) );
		}

		if ( is_product() ) {
			$classes[] = 'hck-product-layout-' . sanitize_html_class( HCK_Helpers::get( 'product_layout', 'gallery-right' ) );
			if ( 'yes' === HCK_Helpers::get( 'product_sticky_info', 'yes' ) ) {
				$classes[] = 'hck-product-sticky';
			}
		}

		if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() ) ) {
			$classes[] = 'hck-shop-layout-' . sanitize_html_class( HCK_Helpers::get( 'shop_layout', 'catalog' ) );
		}

		return $classes;
	}

	/**
	 * Get primary menu items for built-in headers.
	 *
	 * Honours the "Main menu" setting (any registered WordPress menu);
	 * falls back to the primary location, then the first menu, then a
	 * hard-coded Home/Shop list.
	 *
	 * @return array
	 */
	public static function get_menu_items() {
		$locations = get_nav_menu_locations();
		$items     = array();

		$menu_id = 0;

		// 1) Explicitly selected menu from the plugin settings.
		$selected = trim( (string) HCK_Helpers::get( 'header_menu', 'auto' ) );
		if ( '' !== $selected && 'auto' !== $selected ) {
			$menu = wp_get_nav_menu_object( is_numeric( $selected ) ? (int) $selected : $selected );
			if ( $menu ) {
				$menu_id = (int) $menu->term_id;
			}
		}

		// 2) Primary location.
		if ( ! $menu_id && isset( $locations['primary'] ) ) {
			$menu_id = (int) $locations['primary'];
		}

		// 3) First available menu.
		if ( ! $menu_id ) {
			// wp_get_nav_menus() is available on every WordPress 3.0+ install.
			if ( function_exists( 'wp_get_nav_menus' ) ) {
				$menus = wp_get_nav_menus( array( 'number' => 1 ) );
			} else {
				$menus = array();
			}
			if ( ! empty( $menus ) ) {
				$menu_id = (int) $menus[0]->term_id;
			}
		}

		if ( $menu_id && function_exists( 'wp_get_nav_menu_items' ) ) {
			$items = wp_get_nav_menu_items( $menu_id );
			if ( is_wp_error( $items ) ) {
				$items = array();
			}
		}

		if ( empty( $items ) ) {
			$items = array(
				(object) array(
					'title' => __( 'Home', 'hooshyar-commerce-kit' ),
					'url'   => home_url( '/' ),
				),
				(object) array(
					'title' => __( 'Shop', 'hooshyar-commerce-kit' ),
					'url'   => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
				),
			);
		}

		return $items;
	}

	/**
	 * Render the primary navigation markup.
	 *
	 * @return string
	 */
	public static function render_nav() {
		$items = self::get_menu_items();
		$align = sanitize_html_class( HCK_Helpers::get( 'header_menu_align', 'right' ) );

		$html = '<nav class="hck-nav hck-nav--align-' . esc_attr( $align ) . '" aria-label="' . esc_attr__( 'Main navigation', 'hooshyar-commerce-kit' ) . '"><ul class="hck-nav__list">';

		foreach ( $items as $item ) {
			$html .= sprintf(
				'<li class="hck-nav__item"><a class="hck-nav__link" href="%s">%s</a></li>',
				esc_url( $item->url ),
				esc_html( $item->title )
			);
		}

		$html .= '</ul></nav>';

		return $html;
	}

	/**
	 * Render the professional product-category menu (dropdown / mega panel).
	 *
	 * @param array $overrides Optional overrides (used by the Elementor widget).
	 * @return string
	 */
	public static function render_category_menu( $overrides = array() ) {
		$defaults = array(
			'enabled'      => HCK_Helpers::get( 'header_category_menu', 'no' ),
			'label'        => HCK_Helpers::get( 'header_category_menu_label', '' ),
			'style'        => HCK_Helpers::get( 'header_category_menu_style', 'mega' ),
			'columns'      => (int) HCK_Helpers::get( 'header_category_menu_columns', 4 ),
			'show_images'  => HCK_Helpers::get( 'header_category_menu_show_images', 'yes' ),
			'show_counts'  => HCK_Helpers::get( 'header_category_menu_show_counts', 'yes' ),
			'show_children' => HCK_Helpers::get( 'header_category_menu_show_children', 'yes' ),
			'limit'        => (int) HCK_Helpers::get( 'header_category_menu_limit', 12 ),
		);

		$args = wp_parse_args( $overrides, $defaults );

		if ( 'no' === $args['enabled'] || ! taxonomy_exists( 'product_cat' ) ) {
			return '';
		}

		$label = $args['label'] ? $args['label'] : __( 'Categories', 'hooshyar-commerce-kit' );

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => false,
				'orderby'    => 'menu_order',
				'order'      => 'ASC',
				'number'     => max( 1, (int) $args['limit'] ),
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return '';
		}

		$style   = 'mega' === $args['style'] ? 'mega' : 'dropdown';
		$columns = max( 1, min( 6, (int) $args['columns'] ) );

		$html  = '<div class="hck-cats hck-cats--' . esc_attr( $style ) . '" data-hck-cats>';
		$html .= '<button type="button" class="hck-cats__btn" data-hck-cats-toggle aria-expanded="false">';
		$html .= HCK_Helpers::icon( 'grid', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$html .= '<span class="hck-cats__label">' . esc_html( $label ) . '</span>';
		$html .= HCK_Helpers::icon( 'arrow-l', array( 'size' => 14, 'class' => 'hck-cats__caret' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$html .= '</button>';

		$html .= '<div class="hck-cats__panel">';
		$html .= '<div class="hck-cats__head">';
		$html .= HCK_Helpers::icon( 'grid', array( 'size' => 18, 'class' => 'hck-cats__head-icon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$html .= '<span>' . esc_html( $label ) . '</span>';
		$html .= '</div>';

		$html .= '<ul class="hck-cats__list">';

		foreach ( $terms as $term ) {
			$children = array();

			if ( 'yes' === $args['show_children'] ) {
				$children = get_terms(
					array(
						'taxonomy'   => 'product_cat',
						'parent'     => $term->term_id,
						'hide_empty' => false,
						'orderby'    => 'menu_order',
						'order'      => 'ASC',
					)
				);

				if ( is_wp_error( $children ) ) {
					$children = array();
				}
			}

			$has_children = ! empty( $children );
			$term_url     = get_term_link( $term );

			$html .= '<li class="hck-cats__item' . ( $has_children ? ' hck-cats__item--has-children' : '' ) . '">';

			// Row: image + name + count (+ expand button when it has children).
			$html .= '<div class="hck-cats__row">';
			$html .= '<a class="hck-cats__link" href="' . esc_url( $term_url ) . '">';

			if ( 'yes' === $args['show_images'] ) {
				$thumb_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
				if ( $thumb_id ) {
					$html .= '<span class="hck-cats__thumb">' . wp_get_attachment_image( $thumb_id, 'woocommerce_thumbnail' ) . '</span>';
				} else {
					$html .= '<span class="hck-cats__thumb hck-cats__thumb--placeholder">' . HCK_Helpers::icon( 'shop', array( 'size' => 20, 'class' => 'hck-cats__thumb-icon' ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
			}

			$html .= '<span class="hck-cats__name">' . esc_html( $term->name ) . '</span>';

			if ( 'yes' === $args['show_counts'] ) {
				$html .= '<span class="hck-cats__count">' . esc_html( $term->count ) . '</span>';
			}

			$html .= '</a>';

			if ( $has_children ) {
				$html .= '<button type="button" class="hck-cats__more" data-hck-cats-more aria-expanded="false">';
				$html .= HCK_Helpers::icon( 'arrow-l', array( 'size' => 13, 'class' => 'hck-cats__more-icon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
				$html .= '</button>';
			}

			$html .= '</div>';

			// Children — side flyout (mega) or inline accordion (dropdown).
			if ( $has_children ) {
				$html .= '<div class="hck-cats__children">';
				$html .= '<a class="hck-cats__children-title" href="' . esc_url( $term_url ) . '">';
				$html .= '<span>' . esc_html( $term->name ) . '</span>';
				$html .= '<em>' . esc_html__( 'View all', 'hooshyar-commerce-kit' ) . '</em>';
				$html .= '</a>';
				$html .= '<div class="hck-cats__children-grid hck-cats__children-grid--' . esc_attr( $columns ) . '">';

				foreach ( $children as $child ) {
					$html .= '<a class="hck-cats__child" href="' . esc_url( get_term_link( $child ) ) . '">' . esc_html( $child->name ) . '</a>';
				}

				$html .= '</div></div>';
			}

			$html .= '</li>';
		}

		$html .= '</ul>';

		// "View all" footer of the panel.
		$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$html    .= '<a class="hck-cats__all" href="' . esc_url( $shop_url ) . '">';
		$html    .= '<span>' . esc_html__( 'View all products', 'hooshyar-commerce-kit' ) . '</span>';
		$html    .= HCK_Helpers::icon( 'arrow-l', array( 'size' => 15, 'class' => 'hck-cats__all-icon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$html    .= '</a>';
		$html    .= '</div></div>';

		return $html;
	}

	/**
	 * `[hck_category_menu]` shortcode — renders the category menu anywhere.
	 *
	 * Attributes mirror the header settings: label, style (dropdown|mega),
	 * columns, show_images, show_counts, show_children, limit.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode_category_menu( $atts ) {
		$atts = shortcode_atts(
			array(
				'label'         => '',
				'style'         => '',
				'columns'       => 0,
				'show_images'   => '',
				'show_counts'   => '',
				'show_children' => '',
				'limit'         => 0,
			),
			$atts,
			'hck_category_menu'
		);

		$overrides = array( 'enabled' => 'yes' );

		foreach ( $atts as $key => $value ) {
			if ( '' !== $value && '0' !== $value ) {
				$overrides[ $key ] = $value;
			}
		}

		return self::render_category_menu( $overrides );
	}

	/**
	 * Render the header actions (search / user / cart).
	 *
	 * @return string
	 */
	public static function render_actions() {
		$html = '<div class="hck-header-actions">';

		if ( 'yes' === HCK_Helpers::get( 'header_search', 'yes' ) ) {
			$html .= '<form role="search" method="get" class="hck-header-search" action="' . esc_url( home_url( '/' ) ) . '">';
			$html .= '<input type="search" name="s" class="hck-header-search__input" placeholder="' . esc_attr__( 'Search products…', 'hooshyar-commerce-kit' ) . '" value="' . esc_attr( get_search_query() ) . '" />';
			$html .= '<input type="hidden" name="post_type" value="product" />';
			$html .= '<button type="submit" class="hck-header-search__btn" aria-label="' . esc_attr__( 'Search', 'hooshyar-commerce-kit' ) . '">' . HCK_Helpers::icon( 'search', array( 'size' => 19 ) ) . '</button>';
			$html .= '</form>';
		}

		if ( 'yes' === HCK_Helpers::get( 'header_user_button', 'yes' ) ) {
			$html .= HCK_Dashboard::instance()->get_user_button(
				array(
					'show_cart' => 'yes' === HCK_Helpers::get( 'header_cart_button', 'yes' ),
				)
			);
		} elseif ( 'yes' === HCK_Helpers::get( 'header_cart_button', 'yes' ) ) {
			$count    = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
			$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
			$html    .= '<a class="hck-user-area__cart" href="' . esc_url( $cart_url ) . '" data-hck-open-cart aria-label="' . esc_attr__( 'Cart', 'hooshyar-commerce-kit' ) . '">';
			$html    .= HCK_Helpers::icon( 'cart', array( 'size' => 21 ) );
			$html    .= '<span class="hck-cart-count">' . esc_html( $count ) . '</span></a>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Render a full header preset.
	 *
	 * @param string $template Template name.
	 * @return string
	 */
	public static function render_header( $template ) {
		$layout = HCK_Helpers::get( 'header_layout', 'inline' );
		$sticky = 'yes' === HCK_Helpers::get( 'header_sticky', 'yes' );
		$topbar = 'yes' === HCK_Helpers::get( 'header_topbar', 'no' );

		$html = '<header class="hck-header hck-header--' . esc_attr( $template ) . ' hck-header--layout-' . esc_attr( $layout ) . ( $sticky ? ' hck-header--sticky' : '' ) . '">';

		if ( $topbar ) {
			$html .= '<div class="hck-topbar">';
			$html .= '<div class="hck-container hck-topbar__inner">';
			$phone = HCK_Helpers::get( 'header_phone', '' );
			if ( $phone ) {
				$html .= '<span class="hck-topbar__item">' . HCK_Helpers::icon( 'support', array( 'size' => 15 ) ) . ' ' . esc_html( $phone ) . '</span>';
			}
			$html .= '<span class="hck-topbar__item">' . esc_html__( 'Free shipping for orders over a certain amount', 'hooshyar-commerce-kit' ) . '</span>';
			$html .= '</div></div>';
		}

		$html .= '<div class="hck-header__main">';
		$html .= '<div class="hck-container hck-header__inner">';

		$logo = '<a class="hck-logo" href="' . esc_url( home_url( '/' ) ) . '">';
		if ( has_custom_logo() ) {
			$logo .= get_custom_logo();
		} else {
			$logo .= '<span class="hck-logo__mark">' . HCK_Helpers::icon( 'shop', array( 'size' => 24 ) ) . '</span>';
			$logo .= '<span class="hck-logo__text">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
		}
		$logo .= '</a>';

		$nav     = self::render_nav();
		$cats    = self::render_category_menu();
		$actions = self::render_actions();
		$burger  = '<button type="button" class="hck-burger" data-hck-mobile-toggle aria-label="' . esc_attr__( 'Menu', 'hooshyar-commerce-kit' ) . '">' . HCK_Helpers::icon( 'menu' ) . '</button>';

		switch ( $layout ) {
			case 'centered':
				$html .= '<div class="hck-header__row hck-header__row--top">' . $logo . $actions . '</div>';
				$html .= '<div class="hck-header__row hck-header__row--bottom">' . $cats . $nav . $burger . '</div>';
				break;

			case 'split':
				$html .= '<div class="hck-header__row">';
				$html .= '<div class="hck-header__side hck-header__side--start">' . $cats . $nav . '</div>';
				$html .= '<div class="hck-header__side hck-header__side--center">' . $logo . '</div>';
				$html .= '<div class="hck-header__side hck-header__side--end">' . $actions . $burger . '</div>';
				$html .= '</div>';
				break;

			case 'inline':
			default:
				$html .= '<div class="hck-header__row">';
				$html .= $logo;
				$html .= '<div class="hck-header__nav-wrap">' . $cats . $nav . $burger . '</div>';
				$html .= $actions;
				$html .= '</div>';
				break;
		}

		$html .= '</div></div>';
		$html .= '</header>';

		return $html;
	}

	/**
	 * Render a full footer preset.
	 *
	 * @param string $template Template name.
	 * @return string
	 */
	public static function render_footer( $template ) {
		$columns   = (int) HCK_Helpers::get( 'footer_columns', 3 );
		$about     = HCK_Helpers::get( 'footer_about', get_bloginfo( 'description' ) );
		$copyright = HCK_Helpers::get( 'footer_copyright', '© ' . gmdate( 'Y' ) . ' ' . get_bloginfo( 'name' ) );

		$html  = '<footer class="hck-footer hck-footer--' . esc_attr( $template ) . '">';
		$html .= '<div class="hck-container">';
		$html .= '<div class="hck-footer__grid hck-footer__grid--' . esc_attr( $columns ) . '">';

		// Column 1: about.
		$html .= '<div class="hck-footer__col">';
		$html .= '<a class="hck-logo hck-logo--footer" href="' . esc_url( home_url( '/' ) ) . '">';
		if ( has_custom_logo() ) {
			$html .= get_custom_logo();
		} else {
			$html .= '<span class="hck-logo__mark">' . HCK_Helpers::icon( 'shop', array( 'size' => 24 ) ) . '</span>';
			$html .= '<span class="hck-logo__text">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
		}
		$html .= '</a>';
		if ( $about ) {
			$html .= '<p class="hck-footer__about">' . esc_html( $about ) . '</p>';
		}
		$html .= '<div class="hck-footer__social">';
		$html .= '<a href="#" class="hck-footer__social-link" aria-label="Telegram">' . HCK_Helpers::icon( 'telegram', array( 'size' => 18 ) ) . '</a>';
		$html .= '<a href="#" class="hck-footer__social-link" aria-label="Bale">' . HCK_Helpers::icon( 'bale', array( 'size' => 18 ) ) . '</a>';
		$html .= '</div></div>';

		// Column 2: quick links.
		if ( $columns >= 2 ) {
			$shop_url  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
			$cart_url  = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
			$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );

			$html .= '<div class="hck-footer__col">';
			$html .= '<h4 class="hck-footer__title">' . esc_html__( 'Quick links', 'hooshyar-commerce-kit' ) . '</h4>';
			$html .= '<ul class="hck-footer__links">';
			$html .= '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'hooshyar-commerce-kit' ) . '</a></li>';
			$html .= '<li><a href="' . esc_url( $shop_url ) . '">' . esc_html__( 'Shop', 'hooshyar-commerce-kit' ) . '</a></li>';
			$html .= '<li><a href="' . esc_url( $cart_url ) . '">' . esc_html__( 'Cart', 'hooshyar-commerce-kit' ) . '</a></li>';
			$html .= '<li><a href="' . esc_url( $account_url ) . '">' . esc_html__( 'My account', 'hooshyar-commerce-kit' ) . '</a></li>';
			$html .= '</ul></div>';
		}

		// Column 3: contact.
		if ( $columns >= 3 ) {
			$html .= '<div class="hck-footer__col">';
			$html .= '<h4 class="hck-footer__title">' . esc_html__( 'Contact us', 'hooshyar-commerce-kit' ) . '</h4>';
			$phone = HCK_Helpers::get( 'header_phone', '' );
			if ( $phone ) {
				$html .= '<p class="hck-footer__contact">' . HCK_Helpers::icon( 'support', array( 'size' => 16 ) ) . ' ' . esc_html( $phone ) . '</p>';
			}
			$html .= '<p class="hck-footer__contact">' . HCK_Helpers::icon( 'chat', array( 'size' => 16 ) ) . ' ' . esc_html__( 'Support: 24/7', 'hooshyar-commerce-kit' ) . '</p>';
			$html .= '</div>';
		}

		// Column 4: widget area.
		if ( $columns >= 4 ) {
			$html .= '<div class="hck-footer__col">';
			if ( is_active_sidebar( 'hck-footer-1' ) ) {
				ob_start();
				dynamic_sidebar( 'hck-footer-1' );
				$html .= ob_get_clean();
			} else {
				$html .= '<h4 class="hck-footer__title">' . esc_html__( 'Newsletter', 'hooshyar-commerce-kit' ) . '</h4>';
				$html .= '<p class="hck-footer__about">' . esc_html__( 'Subscribe to get the latest offers.', 'hooshyar-commerce-kit' ) . '</p>';
			}
			$html .= '</div>';
		}

		$html .= '</div>'; // grid.

		$html .= '<div class="hck-footer__bottom">';
		$html .= '<p>' . wp_kses_post( $copyright ) . '</p>';
		$html .= '<p class="hck-footer__brand">' . esc_html__( 'Powered by Hooshyar Commerce Kit', 'hooshyar-commerce-kit' ) . '</p>';
		$html .= '</div>';

		$html .= '</div></footer>';

		return $html;
	}

	/**
	 * Render an Elementor template by id (header/footer in template mode).
	 *
	 * @param int $template_id Template ID.
	 * @return string
	 */
	public static function render_elementor_template( $template_id ) {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return '';
		}

		$content = \Elementor\Plugin::instance()->frontend->get_builder_content( (int) $template_id, true );
		return $content ? $content : '';
	}
}
